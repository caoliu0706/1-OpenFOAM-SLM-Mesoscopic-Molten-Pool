/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011-2018 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "caoliuConvectionFvPatchScalarField.H"
#include "addToRunTimeSelectionTable.H"
#include "fvPatchFieldMapper.H"
#include "volFields.H"
#include "surfaceFields.H"

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

Foam::caoliuConvectionFvPatchScalarField::
caoliuConvectionFvPatchScalarField
(
    const fvPatch& p,
    const DimensionedField<scalar, volMesh>& iF
)
:
    fixedGradientFvPatchScalarField(p, iF),
    MixedhcName_("Mixedhc"),
    phase1alpha_("phase1alpha"),
    alpha1convective_(1000),
    alpha2convective_(100),
    outsidetemperature_(30)
{}


Foam::caoliuConvectionFvPatchScalarField::
caoliuConvectionFvPatchScalarField
(
    const fvPatch& p,
    const DimensionedField<scalar, volMesh>& iF,
    const dictionary& dict
)
:
    fixedGradientFvPatchScalarField(p, iF),
    MixedhcName_(dict.lookupOrDefault<word>("Mixedhc", "Mixedhc")),
    phase1alpha_(dict.lookupOrDefault<word>("phase1alpha", "phase1alpha")),
    alpha1convective_(readScalar(dict.lookup("alpha1convective"))),
    alpha2convective_(readScalar(dict.lookup("alpha2convective"))),
    outsidetemperature_(readScalar(dict.lookup("outsidetemperature")))
{
    if (dict.found("value") && dict.found("gradient"))
    {
        fvPatchField<scalar>::operator=
        (
            scalarField("value", dict, p.size())
        );
        gradient() = scalarField("gradient", dict, p.size());
    }
    else
    {
        fvPatchField<scalar>::operator=(patchInternalField());
        gradient() = 0;
    }
}


Foam::caoliuConvectionFvPatchScalarField::
caoliuConvectionFvPatchScalarField
(
    const caoliuConvectionFvPatchScalarField& ptf,
    const fvPatch& p,
    const DimensionedField<scalar, volMesh>& iF,
    const fvPatchFieldMapper& mapper
)
:
    fixedGradientFvPatchScalarField(ptf, p, iF, mapper),
    MixedhcName_(ptf.MixedhcName_),
    phase1alpha_(ptf.phase1alpha_),
    alpha1convective_(ptf.alpha1convective_),
    alpha2convective_(ptf.alpha2convective_),
    outsidetemperature_(ptf.outsidetemperature_)
{}


Foam::caoliuConvectionFvPatchScalarField::
caoliuConvectionFvPatchScalarField
(
    const caoliuConvectionFvPatchScalarField& clcpsf
)
:
    fixedGradientFvPatchScalarField(clcpsf),
    MixedhcName_(clcpsf.MixedhcName_),
    phase1alpha_(clcpsf.phase1alpha_),
    alpha1convective_(clcpsf.alpha1convective_),
    alpha2convective_(clcpsf.alpha2convective_),
    outsidetemperature_(clcpsf.outsidetemperature_)
{}


Foam::caoliuConvectionFvPatchScalarField::
caoliuConvectionFvPatchScalarField
(
    const caoliuConvectionFvPatchScalarField& clcpsf,
    const DimensionedField<scalar, volMesh>& iF
)
:
    fixedGradientFvPatchScalarField(clcpsf, iF),
    MixedhcName_(clcpsf.MixedhcName_),
    phase1alpha_(clcpsf.phase1alpha_),
    alpha1convective_(clcpsf.alpha1convective_),
    alpha2convective_(clcpsf.alpha2convective_),
    outsidetemperature_(clcpsf.outsidetemperature_)
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void Foam::caoliuConvectionFvPatchScalarField::updateCoeffs()
{
    if (updated())
    {
        return;
    }

    const fvPatchField<scalar>& Mixedhcp =
        patch().lookupPatchField<volScalarField, scalar>(MixedhcName_);

    const fvPatchField<scalar>& phase1alphap =
        patch().lookupPatchField<volScalarField, scalar>(phase1alpha_);

    const scalarField Tin(patchInternalField());

    forAll(Tin, facei)
    {
        scalar i_alpha1, i_alpha2;
        i_alpha1=phase1alphap[facei];
        i_alpha2=max(1.0-i_alpha1, 0.0);

        gradient()[facei] = ((i_alpha1*alpha1convective()+i_alpha2*alpha2convective())*(outsidetemperature()-Tin[facei]))/Mixedhcp[facei];
    }

    fixedGradientFvPatchScalarField::updateCoeffs();
}


void Foam::caoliuConvectionFvPatchScalarField::write(Ostream& os) const
{
    fixedGradientFvPatchScalarField::write(os);
    writeEntryIfDifferent<word>(os, "Mixedhc", "Mixedhc", MixedhcName_);
    writeEntryIfDifferent<word>(os, "phase1alpha", "phase1alpha", phase1alpha_);
    os.writeKeyword("alpha1convective") << alpha1convective_ << token::END_STATEMENT << nl;
    os.writeKeyword("alpha2convective") << alpha2convective_ << token::END_STATEMENT << nl;
    os.writeKeyword("outsidetemperature") << outsidetemperature_ << token::END_STATEMENT << nl;
    writeEntry("value", os);
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{
    makePatchTypeField
    (
        fvPatchScalarField,
        caoliuConvectionFvPatchScalarField
    );
}

// ************************************************************************* //
